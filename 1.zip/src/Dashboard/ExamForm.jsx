import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import { useDropzone } from "react-dropzone";
import "../css/ExamForm.css";
import Sidebar from "./SideBar";

const ExamForm = () => {
  const location = useLocation();
  const [title, setTitle] = useState(location.state ? location.state.title : "");
  const [questionType, setQuestionType] = useState("");
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState({
    question: "",
    options: ["", ""],
    correctAnswer: "",
    answerDescription: "",
  });

  const { acceptedFiles, getRootProps, getInputProps } = useDropzone({
    onDrop: (acceptedFiles) => {
      console.log(acceptedFiles);
    },
  });

  const handleQuestionTypeChange = (event) => {
    setQuestionType(event.target.value);
  };

  const handleOptionChange = (index, event) => {
    const { value } = event.target;
    if (value.length <= 150) {
      const updatedOptions = [...currentQuestion.options];
      updatedOptions[index] = value;
      setCurrentQuestion({
        ...currentQuestion,
        options: updatedOptions,
      });
    }
  };

  const handleAddOption = () => {
    setCurrentQuestion({
      ...currentQuestion,
      options: [...currentQuestion.options, ""],
    });
  };

  const handleRemoveOption = (index) => {
    const updatedOptions = currentQuestion.options.filter(
      (_, optionIndex) => optionIndex !== index
    );
    setCurrentQuestion({
      ...currentQuestion,
      options: updatedOptions,
    });
  };

  const handleAddQuestion = () => {
    if (!currentQuestion.options.includes(currentQuestion.correctAnswer)) {
      alert("Please ensure that the correct answer is one of the options.");
      return;
    }

    setQuestions([...questions, currentQuestion]);
    setCurrentQuestion({
      question: "",
      options: ["", ""],
      correctAnswer: "",
      answerDescription: "",
    });
  };

  const handleSubmitAllQuestions = () => {
    console.log(questions);
  };

  return (
    <div className="container-examform px-4 mt-6 ">
      <div className="row gx-5">
        <div className="col">
          <div className="p-3 border bg-light">
            <h2 className="Exam-form">Exam Form</h2>
            <p>Title: {title}</p>
            <form>
              <div className="form-group">
                <select
                  className="form-select"
                  id="questionType"
                  name="questionType"
                  value={questionType}
                  onChange={handleQuestionTypeChange}
                >
                  <option value="">Select Question Type</option>
                  <option value="MCQ">Multiple Choice Questions</option>
                  <option value="Subjective">Subjective</option>
                </select>
              </div>
            </form>
            {questionType === "MCQ" && (
              <div className="container-mcq px-4">
                <div className="row gx-5">
                  <div className="col-mcq col-md-8 col-lg-8">
                    <h3 className="Add-MCQ">Add MCQ Question</h3>
                    <div className="form-group">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Question"
                        aria-label="Question"
                        id="question"
                        name="question"
                        value={currentQuestion.question}
                        onChange={(e) =>
                          setCurrentQuestion({
                            ...currentQuestion,
                            question: e.target.value,
                          })
                        }
                      />
                    </div>
                    {currentQuestion.options.map((option, index) => (
                      <div key={index} className="form-group">
                        <input
                          type="text"
                          className="form-control"
                          placeholder={`Option ${index + 1}`}
                          aria-label={`Option ${index + 1}`}
                          id={`option${index + 1}`}
                          name={`option${index + 1}`}
                          value={option}
                          onChange={(e) => handleOptionChange(index, e)}
                        />
                        {index >= 2 && (
                          <button
                            type="button"
                            className="btn btn-danger mt-3 w-25 float-right "
                            onClick={() => handleRemoveOption(index)}
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    ))}
                    <div className="form-group">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Enter correct answer"
                        aria-label="Enter correct answer"
                        id="correctAnswer"
                        name="correctAnswer"
                        value={currentQuestion.correctAnswer}
                        onChange={(e) =>
                          setCurrentQuestion({
                            ...currentQuestion,
                            correctAnswer: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="form-group">
                      <textarea
                        className="form-control"
                        id="answerDescription"
                        placeholder="Enter answer description"
                        aria-label="Enter answer description"
                        name="answerDescription"
                        value={currentQuestion.answerDescription}
                        onChange={(e) =>
                          setCurrentQuestion({
                            ...currentQuestion,
                            answerDescription: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="d-flex justify-content-between">
                      <button
                        type="button"
                        className="btn btn-primary mt-3 w-25"
                        onClick={handleAddOption}
                      >
                        Add Option
                      </button>
                      <button
                        type="button"
                        className="btn btn-primary mt-3 w-25"
                        onClick={handleAddQuestion}
                      >
                        Submit Question
                      </button>
                    </div>
                  </div>
                  <div className="px-4 col-md-4 col-lg-4">
                    <div className="p-3 border bg-light h-100">
                      <h3 className="import">Import Question Paper</h3>
                      <div {...getRootProps({ className: "dropzone" })}>
                        <input {...getInputProps()} />
                        <p>Drag an Excel file (.xlsx) here to upload.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {questionType === "Subjective" && (
              <div className="container-subjective px-4">
                <div className="row gx-5">
                  <div className="col-subjective col-md-8 col-lg-8">
                    <h3 className="Add-Subjective">Add Subjective Question</h3>
                    <div className="form-group">
                      <input
                        type="text"
                        className="form-control"
                        id="subjectiveQuestion"
                        placeholder="Question"
                        aria-label="Question"
                        name="subjectiveQuestion"
                        value={currentQuestion.question}
                        onChange={(e) =>
                          setCurrentQuestion({
                            ...currentQuestion,
                            question: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="form-group">
                      <textarea
                        className="form-control"
                        id="answerDescription"
                        placeholder="Enter answer description"
                        aria-label="Enter answer description"
                        name="answerDescription"
                        value={currentQuestion.answerDescription}
                        onChange={(e) =>
                          setCurrentQuestion({
                            ...currentQuestion,
                            answerDescription: e.target.value,
                          })
                        }
                      />
                    </div>

                    <div className="d-flex justify-content-between">
                      <button
                        type="button"
                        className="btn btn-primary mt-3 w-25"
                        onClick={handleAddQuestion}
                      >
                        Submit Question
                      </button>
                    </div>
                  </div>
                  <div className="px-4 col-md-4 col-lg-4 ">
                    <div className="p-3 border bg-light">
                      <h3 className="import">Import Question Paper</h3>
                      <div {...getRootProps({ className: "dropzone" })}>
                        <input {...getInputProps()} />
                        <p>Drag an Excel file (.xlsx) here to upload.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {(questions.length > 0 || questionType === "Subjective") && (
              <button
                type="button"
                className="btn btn-primary mt-2 d-block mx-auto"
                onClick={handleSubmitAllQuestions}
              >
                Submit Questions Paper
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamForm;
